﻿namespace TH09_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelleriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.otherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.dgv = new System.Windows.Forms.DataGridView();
            this.tb_subtotal = new System.Windows.Forms.TextBox();
            this.tb_total = new System.Windows.Forms.TextBox();
            this.l = new System.Windows.Forms.Label();
            this.la = new System.Windows.Forms.Label();
            this.item1 = new System.Windows.Forms.Label();
            this.price1 = new System.Windows.Forms.Label();
            this.price2 = new System.Windows.Forms.Label();
            this.item2 = new System.Windows.Forms.Label();
            this.price3 = new System.Windows.Forms.Label();
            this.item3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.b_addcart3 = new System.Windows.Forms.Button();
            this.b_addcart2 = new System.Windows.Forms.Button();
            this.b_addcart1 = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.b_up = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_nameoth = new System.Windows.Forms.TextBox();
            this.tb_priceoth = new System.Windows.Forms.TextBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.b_addoth = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.b_del = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.otherToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1717, 48);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(134, 40);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(219, 44);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(219, 44);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(174, 40);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(263, 44);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(263, 44);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelleriesToolStripMenuItem});
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(155, 40);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(261, 44);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelleriesToolStripMenuItem
            // 
            this.jewelleriesToolStripMenuItem.Name = "jewelleriesToolStripMenuItem";
            this.jewelleriesToolStripMenuItem.Size = new System.Drawing.Size(261, 44);
            this.jewelleriesToolStripMenuItem.Text = "Jewelleries";
            this.jewelleriesToolStripMenuItem.Click += new System.EventHandler(this.jewelleriesToolStripMenuItem_Click);
            // 
            // otherToolStripMenuItem
            // 
            this.otherToolStripMenuItem.Name = "otherToolStripMenuItem";
            this.otherToolStripMenuItem.Size = new System.Drawing.Size(105, 40);
            this.otherToolStripMenuItem.Text = "Others";
            this.otherToolStripMenuItem.Click += new System.EventHandler(this.otherToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // dgv
            // 
            this.dgv.AllowUserToAddRows = false;
            this.dgv.AllowUserToDeleteRows = false;
            this.dgv.AllowUserToResizeColumns = false;
            this.dgv.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgv.Location = new System.Drawing.Point(820, 70);
            this.dgv.MultiSelect = false;
            this.dgv.Name = "dgv";
            this.dgv.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgv.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dgv.RowTemplate.Height = 33;
            this.dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv.Size = new System.Drawing.Size(847, 466);
            this.dgv.TabIndex = 2;
            this.dgv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellClick);
            // 
            // tb_subtotal
            // 
            this.tb_subtotal.Location = new System.Drawing.Point(993, 612);
            this.tb_subtotal.Name = "tb_subtotal";
            this.tb_subtotal.Size = new System.Drawing.Size(271, 31);
            this.tb_subtotal.TabIndex = 3;
            this.tb_subtotal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_total_KeyPress);
            // 
            // tb_total
            // 
            this.tb_total.Location = new System.Drawing.Point(993, 564);
            this.tb_total.Name = "tb_total";
            this.tb_total.Size = new System.Drawing.Size(271, 31);
            this.tb_total.TabIndex = 4;
            this.tb_total.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_total_KeyPress);
            // 
            // l
            // 
            this.l.AutoSize = true;
            this.l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l.Location = new System.Drawing.Point(816, 564);
            this.l.Name = "l";
            this.l.Size = new System.Drawing.Size(150, 31);
            this.l.TabIndex = 5;
            this.l.Text = "Sub-Total:";
            // 
            // la
            // 
            this.la.AutoSize = true;
            this.la.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.la.Location = new System.Drawing.Point(877, 609);
            this.la.Name = "la";
            this.la.Size = new System.Drawing.Size(89, 31);
            this.la.TabIndex = 6;
            this.la.Text = "Total:";
            // 
            // item1
            // 
            this.item1.AutoSize = true;
            this.item1.Location = new System.Drawing.Point(24, 310);
            this.item1.Name = "item1";
            this.item1.Size = new System.Drawing.Size(70, 25);
            this.item1.TabIndex = 10;
            this.item1.Text = "label3";
            // 
            // price1
            // 
            this.price1.AutoSize = true;
            this.price1.Location = new System.Drawing.Point(24, 375);
            this.price1.Name = "price1";
            this.price1.Size = new System.Drawing.Size(70, 25);
            this.price1.TabIndex = 11;
            this.price1.Text = "label4";
            // 
            // price2
            // 
            this.price2.AutoSize = true;
            this.price2.Location = new System.Drawing.Point(288, 375);
            this.price2.Name = "price2";
            this.price2.Size = new System.Drawing.Size(70, 25);
            this.price2.TabIndex = 13;
            this.price2.Text = "label5";
            // 
            // item2
            // 
            this.item2.AutoSize = true;
            this.item2.Location = new System.Drawing.Point(288, 310);
            this.item2.Name = "item2";
            this.item2.Size = new System.Drawing.Size(70, 25);
            this.item2.TabIndex = 12;
            this.item2.Text = "label6";
            // 
            // price3
            // 
            this.price3.AutoSize = true;
            this.price3.Location = new System.Drawing.Point(549, 375);
            this.price3.Name = "price3";
            this.price3.Size = new System.Drawing.Size(70, 25);
            this.price3.TabIndex = 15;
            this.price3.Text = "label7";
            // 
            // item3
            // 
            this.item3.AutoSize = true;
            this.item3.Location = new System.Drawing.Point(549, 310);
            this.item3.Name = "item3";
            this.item3.Size = new System.Drawing.Size(70, 25);
            this.item3.TabIndex = 14;
            this.item3.Text = "label8";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.b_addcart3);
            this.panel1.Controls.Add(this.b_addcart2);
            this.panel1.Controls.Add(this.b_addcart1);
            this.panel1.Controls.Add(this.price3);
            this.panel1.Controls.Add(this.item3);
            this.panel1.Controls.Add(this.price2);
            this.panel1.Controls.Add(this.item2);
            this.panel1.Controls.Add(this.price1);
            this.panel1.Controls.Add(this.item1);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(12, 57);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(764, 479);
            this.panel1.TabIndex = 16;
            this.panel1.Visible = false;
            // 
            // b_addcart3
            // 
            this.b_addcart3.Location = new System.Drawing.Point(532, 414);
            this.b_addcart3.Name = "b_addcart3";
            this.b_addcart3.Size = new System.Drawing.Size(147, 48);
            this.b_addcart3.TabIndex = 18;
            this.b_addcart3.Text = "Add Cart";
            this.b_addcart3.UseVisualStyleBackColor = true;
            this.b_addcart3.Click += new System.EventHandler(this.b_addcart3_Click);
            // 
            // b_addcart2
            // 
            this.b_addcart2.Location = new System.Drawing.Point(274, 414);
            this.b_addcart2.Name = "b_addcart2";
            this.b_addcart2.Size = new System.Drawing.Size(147, 48);
            this.b_addcart2.TabIndex = 17;
            this.b_addcart2.Text = "Add Cart";
            this.b_addcart2.UseVisualStyleBackColor = true;
            this.b_addcart2.Click += new System.EventHandler(this.b_addcart2_Click);
            // 
            // b_addcart1
            // 
            this.b_addcart1.Location = new System.Drawing.Point(29, 414);
            this.b_addcart1.Name = "b_addcart1";
            this.b_addcart1.Size = new System.Drawing.Size(147, 48);
            this.b_addcart1.TabIndex = 16;
            this.b_addcart1.Text = "Add Cart";
            this.b_addcart1.UseVisualStyleBackColor = true;
            this.b_addcart1.Click += new System.EventHandler(this.b_addcart1_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(532, 14);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(210, 265);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 9;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(274, 14);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(210, 265);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(14, 14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(210, 265);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(68, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 25);
            this.label1.TabIndex = 19;
            this.label1.Text = "Upload Image";
            // 
            // b_up
            // 
            this.b_up.Location = new System.Drawing.Point(247, 15);
            this.b_up.Name = "b_up";
            this.b_up.Size = new System.Drawing.Size(147, 46);
            this.b_up.TabIndex = 19;
            this.b_up.Text = "Upload";
            this.b_up.UseVisualStyleBackColor = true;
            this.b_up.Click += new System.EventHandler(this.b_up_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(249, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 25);
            this.label2.TabIndex = 20;
            this.label2.Text = "Item Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(249, 182);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 25);
            this.label3.TabIndex = 21;
            this.label3.Text = "Item Price";
            // 
            // tb_nameoth
            // 
            this.tb_nameoth.Enabled = false;
            this.tb_nameoth.Location = new System.Drawing.Point(254, 130);
            this.tb_nameoth.Name = "tb_nameoth";
            this.tb_nameoth.Size = new System.Drawing.Size(209, 31);
            this.tb_nameoth.TabIndex = 22;
            this.tb_nameoth.TextChanged += new System.EventHandler(this.tb_nameoth_TextChanged);
            // 
            // tb_priceoth
            // 
            this.tb_priceoth.Enabled = false;
            this.tb_priceoth.Location = new System.Drawing.Point(254, 220);
            this.tb_priceoth.Name = "tb_priceoth";
            this.tb_priceoth.Size = new System.Drawing.Size(209, 31);
            this.tb_priceoth.TabIndex = 23;
            this.tb_priceoth.TextChanged += new System.EventHandler(this.tb_nameoth_TextChanged);
            this.tb_priceoth.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_priceoth_KeyPress);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(18, 68);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(210, 302);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 19;
            this.pictureBox4.TabStop = false;
            // 
            // b_addoth
            // 
            this.b_addoth.Enabled = false;
            this.b_addoth.Location = new System.Drawing.Point(254, 298);
            this.b_addoth.Name = "b_addoth";
            this.b_addoth.Size = new System.Drawing.Size(147, 47);
            this.b_addoth.TabIndex = 19;
            this.b_addoth.Text = "Add Cart";
            this.b_addoth.UseVisualStyleBackColor = true;
            this.b_addoth.Click += new System.EventHandler(this.b_addoth_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.b_addoth);
            this.panel2.Controls.Add(this.pictureBox4);
            this.panel2.Controls.Add(this.tb_priceoth);
            this.panel2.Controls.Add(this.tb_nameoth);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.b_up);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(177, 564);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(485, 391);
            this.panel2.TabIndex = 24;
            this.panel2.Visible = false;
            // 
            // panel3
            // 
            this.panel3.Location = new System.Drawing.Point(1682, 71);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(66, 464);
            this.panel3.TabIndex = 25;
            // 
            // b_del
            // 
            this.b_del.Location = new System.Drawing.Point(1371, 577);
            this.b_del.Name = "b_del";
            this.b_del.Size = new System.Drawing.Size(147, 48);
            this.b_del.TabIndex = 19;
            this.b_del.Text = "Delete";
            this.b_del.UseVisualStyleBackColor = true;
            this.b_del.Click += new System.EventHandler(this.b_del_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1717, 964);
            this.Controls.Add(this.b_del);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.la);
            this.Controls.Add(this.l);
            this.Controls.Add(this.tb_total);
            this.Controls.Add(this.tb_subtotal);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "UNIQME";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelleriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem otherToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.TextBox tb_subtotal;
        private System.Windows.Forms.TextBox tb_total;
        private System.Windows.Forms.Label l;
        private System.Windows.Forms.Label la;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label item1;
        private System.Windows.Forms.Label price1;
        private System.Windows.Forms.Label price2;
        private System.Windows.Forms.Label item2;
        private System.Windows.Forms.Label price3;
        private System.Windows.Forms.Label item3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button b_addcart3;
        private System.Windows.Forms.Button b_addcart2;
        private System.Windows.Forms.Button b_addcart1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button b_addoth;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.TextBox tb_priceoth;
        private System.Windows.Forms.TextBox tb_nameoth;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button b_up;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button b_del;
    }
}

