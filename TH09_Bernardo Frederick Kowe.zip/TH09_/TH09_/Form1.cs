﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH09_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int cek = 0;
        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
            pictureBox1.Image = Properties.Resources.Kongzen_T_shirt;
            pictureBox2.Image = Properties.Resources.Japanese_Graphic_T_Shirt;
            pictureBox3.Image = Properties.Resources.Jealousy_T_shirt;
            item1.Text = "Kongzen T-shirt";
            item2.Text = "Japanese Graphic T-Shirt";
            item3.Text = "Jealousy T-shirt";

            int a = 100000;
            int b = 75000;
            int c = 95000;

            string aa = a.ToString("C2").Remove(0, 1);
            string bb = b.ToString("C2").Remove(0, 1);
            string cc = c.ToString("C2").Remove(0, 1);
            price1.Text = "Rp. " + aa.Remove(aa.Length - 3, 3) + ",-";
            price2.Text = "Rp. " + bb.Remove(bb.Length - 3, 3) + ",-";
            price3.Text = "Rp. " + cc.Remove(cc.Length - 3, 3) + ",-";

            cek = 1;
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
            pictureBox1.Image = Properties.Resources.TikTokShirt;
            pictureBox2.Image = Properties.Resources.GemoyShirt;
            pictureBox3.Image = Properties.Resources.MelodyShirt;
            item1.Text = "TikTok Shirt";
            item2.Text = "Gemoy Shirt";
            item3.Text = "Melody Pink Shirt";

            int a = 30000;
            int b = 45000;
            int c = 40000;

            string aa = a.ToString("C2").Remove(0, 1);
            string bb = b.ToString("C2").Remove(0, 1);
            string cc = c.ToString("C2").Remove(0, 1);
            price1.Text = "Rp. " + aa.Remove(aa.Length - 3, 3) + ",-";
            price2.Text = "Rp. " + bb.Remove(bb.Length - 3, 3) + ",-";
            price3.Text = "Rp. " + cc.Remove(cc.Length - 3, 3) + ",-";

            cek = 2;
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
            pictureBox1.Image = Properties.Resources.Iris_Khaki_Pants;
            pictureBox2.Image = Properties.Resources.YellowHotPants;
            pictureBox3.Image = Properties.Resources.Jeans_Bordir_Pants;
            item1.Text = "Iris Khaki Pants";
            item2.Text = "Yellow Hot Pants";
            item3.Text = "Jeans Bordir Pants";

            int a = 35000;
            int b = 60000;
            int c = 50000;

            string aa = a.ToString("C2").Remove(0, 1);
            string bb = b.ToString("C2").Remove(0, 1);
            string cc = c.ToString("C2").Remove(0, 1);
            price1.Text = "Rp. " + aa.Remove(aa.Length - 3, 3) + ",-";
            price2.Text = "Rp. " + bb.Remove(bb.Length - 3, 3) + ",-";
            price3.Text = "Rp. " + cc.Remove(cc.Length - 3, 3) + ",-";

            cek = 3;
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
            pictureBox1.Image = Properties.Resources.Long_Pants_Bring_Up_a_Name;
            pictureBox2.Image = Properties.Resources.Basic_Jeans;
            pictureBox3.Image = Properties.Resources.Slim_Fit_Men_Jeans;
            item1.Text = "Long Pants Bring \nUp a Name";
            item2.Text = "Basic Jeans";
            item3.Text = "Slim Fit Jeans";

            int a = 100000;
            int b = 200000;
            int c = 175000;

            string aa = a.ToString("C2").Remove(0, 1);
            string bb = b.ToString("C2").Remove(0, 1);
            string cc = c.ToString("C2").Remove(0, 1);
            price1.Text = "Rp. " + aa.Remove(aa.Length - 3, 3) + ",-";
            price2.Text = "Rp. " + bb.Remove(bb.Length - 3, 3) + ",-";
            price3.Text = "Rp. " + cc.Remove(cc.Length - 3, 3) + ",-";

            cek = 4;
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
            pictureBox1.Image = Properties.Resources.ArdilesNfinityBurst;
            pictureBox2.Image = Properties.Resources.ConverseRunStar;
            pictureBox3.Image = Properties.Resources.MillsTreximo;
            item1.Text = "Sepatu Running Ardiles \nNfinity Burst";
            item2.Text = "Converse Run Star High";
            item3.Text = "Mills Treximo Saga\nV2 Lime";

            int a = 425000;
            int b = 1199000;
            int c = 500000;

            string aa = a.ToString("C2").Remove(0, 1);
            string bb = b.ToString("C2").Remove(0, 1);
            string cc = c.ToString("C2").Remove(0, 1);
            price1.Text = "Rp. " + aa.Remove(aa.Length - 3, 3) + ",-";
            price2.Text = "Rp. " + bb.Remove(bb.Length - 3, 3) + ",-";
            price3.Text = "Rp. " + cc.Remove(cc.Length - 3, 3) + ",-";

            cek = 5;
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
            pictureBox1.Image = Properties.Resources.LancelotGuthrum;
            pictureBox2.Image = Properties.Resources.Cincin_Pandora;
            pictureBox3.Image = Properties.Resources.EiliGermany;
            item1.Text = "Lanccelot Guthrum Watch";
            item2.Text = "Pandora Triple Band\nRing";
            item3.Text = "Eili Collar Necklace";

            int a = 749000;
            int b = 1890000;
            int c = 783300;

            string aa = a.ToString("C2").Remove(0, 1);
            string bb = b.ToString("C2").Remove(0, 1);
            string cc = c.ToString("C2").Remove(0, 1);
            price1.Text = "Rp. " + aa.Remove(aa.Length - 3, 3) + ",-";
            price2.Text = "Rp. " + bb.Remove(bb.Length - 3, 3) + ",-";
            price3.Text = "Rp. " + cc.Remove(cc.Length - 3, 3) + ",-";

            cek = 6;
        }
        int total = 0;
        private void b_addcart1_Click(object sender, EventArgs e)
        {
            int a = 0;

            if (cek == 1)
            {
                a = 100000;
            }
            else if (cek == 2)
            {
                a = 30000;
            }
            else if (cek == 3)
            {
                a = 35000;
            }
            else if (cek == 4)
            {
                a = 100000;
            }
            else if (cek == 5)
            {
                a = 425000;
            }
            else if (cek == 6)
            {
                a = 749000;
            }

            bool tes = false;
            for (int i = 0; i < barang.Count; i++)
            {
                if(item1.Text == barang[i])
                {
                    tes = true;
                }
            }

            if (tes == true)
            {
                for (int i = 0; i < dtstock.Rows.Count; i++)
                {
                    if (item1.Text == dtstock.Rows[i][0].ToString())
                    {
                        int qty = (Convert.ToInt32(dtstock.Rows[i][1]) + 1);
                        string tot = (a * qty).ToString("C2").Remove(0, 1);
                        dtstock.Rows[i][1] = qty.ToString();
                        dtstock.Rows[i][3] = "Rp. " + tot.Remove(tot.Length - 3, 3) + ",-";
                        break;
                    }
                }
            }
            else
            {
                dtstock.Rows.Add(item1.Text, '1', price1.Text, price1.Text);
                barang.Add(item1.Text);
            }
            total = total + a;
            int subtotal = total + (total * 10 / 100);
            string sub = subtotal.ToString("C2").Remove(0, 1);
            tb_subtotal.Text = "Rp. " + sub.Remove(sub.Length - 3, 3) + ",-";
            string to = total.ToString("C2").Remove(0, 1);
            tb_total.Text = "Rp. " + to.Remove(to.Length - 3, 3) + ",-";

            dgv.ClearSelection();
        }

        private void b_addcart2_Click(object sender, EventArgs e)
        {
            int b = 0;


            if (cek == 1)
            {
                b = 75000;

            }
            else if (cek == 2)
            {
                b = 45000;
            }
            else if (cek == 3)
            {
                b = 60000;
            }
            else if (cek == 4)
            {
                b = 200000;
            }
            else if (cek == 5)
            {
                b = 1199000;
            }
            else if (cek == 6)
            {
                b = 1890000;
            }

            bool tes = false;
            for (int i = 0; i < barang.Count; i++)
            {
                if (item2.Text == barang[i])
                {
                    tes = true;
                }
            }

            if (tes == true)
            {
                for (int i = 0; i < dtstock.Rows.Count ; i++)
                {
                    if (item2.Text == dtstock.Rows[i][0].ToString())
                    {
                        int qty = (Convert.ToInt32(dtstock.Rows[i][1]) + 1);
                        string tot = (b * qty).ToString("C2").Remove(0, 1);
                        dtstock.Rows[i][1] = qty.ToString();
                        dtstock.Rows[i][3] = "Rp. " + tot.Remove(tot.Length - 3, 3) + ",-";
                        break;
                    }
                }
            }
            else
            {
                dtstock.Rows.Add(item2.Text, '1', price2.Text, price2.Text);
                barang.Add(item2.Text);
            }
            total = total + b;
            int subtotal = total + (total * 10 / 100);
            string sub = subtotal.ToString("C2").Remove(0, 1);
            tb_subtotal.Text = "Rp. " + sub.Remove(sub.Length - 3, 3) + ",-";
            string to = total.ToString("C2").Remove(0, 1);
            tb_total.Text = "Rp. " + to.Remove(to.Length - 3, 3) + ",-";

            dgv.ClearSelection();
        }

        private void b_addcart3_Click(object sender, EventArgs e)
        {
            int c = 0;

            if (cek == 1)
            {
                c = 95000;

            }
            else if (cek == 2)
            {
                c = 40000;
            }
            else if (cek == 3)
            {
                c = 50000;
            }
            else if (cek == 4)
            {
                c = 175000;
            }
            else if (cek == 5)
            {
                c = 500000;
            }
            else if (cek == 6)
            {
                c = 783300;
            }

            bool tes = false;
            for (int i = 0; i < barang.Count; i++)
            {
                if (item3.Text == barang[i])
                {
                    tes = true;
                }
            }

            if (tes == true)
            {
                for (int i = 0; i < dtstock.Rows.Count; i++)
                {
                    if (item3.Text == dtstock.Rows[i][0].ToString())
                    {
                        int qty = (Convert.ToInt32(dtstock.Rows[i][1]) + 1);
                        string tot = (c * qty).ToString("C2").Remove(0, 1);
                        dtstock.Rows[i][1] = qty.ToString();
                        dtstock.Rows[i][3] = "Rp. " + tot.Remove(tot.Length - 3, 3) + ",-";
                        break;
                    }
                }
            }
            else
            {
                dtstock.Rows.Add(item3.Text, '1', price3.Text, price3.Text);
                barang.Add(item3.Text);
            }
            total = total + c;
            int subtotal = total + (total * 10 / 100);
            string sub = subtotal.ToString("C2").Remove(0, 1);
            tb_subtotal.Text = "Rp. " + sub.Remove(sub.Length - 3, 3) + ",-";
            string to = total.ToString("C2").Remove(0, 1);
            tb_total.Text = "Rp. " + to.Remove(to.Length - 3, 3) + ",-";

            dgv.ClearSelection();
        }
        DataTable dtstock = new DataTable();
        List<string> barang = new List<string>();
        private void Form1_Load(object sender, EventArgs e)
        {
            panel2.Top = 40;
            panel2.Left = 97;
            dtstock.Columns.Add("Item Name");
            dtstock.Columns.Add("Quantity");
            dtstock.Columns.Add("Price");
            dtstock.Columns.Add("Total");
            dgv.DataSource = dtstock;

            int subtotal = total + (total * 10 / 100);
            string sub = subtotal.ToString("C2").Remove(0, 1);
            tb_subtotal.Text = "Rp. " + sub.Remove(sub.Length - 3, 3) + ",-";
            string to = total.ToString("C2").Remove(0, 1);
            tb_total.Text = "Rp. " + to.Remove(to.Length - 3, 3) + ",-";
        }

        private void otherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel2.Visible = true;
        }

        private void b_addoth_Click(object sender, EventArgs e)
        {
            if (tb_priceoth.Text != "" && tb_nameoth.Text != "")
            {
                string pricee = (Convert.ToInt32(tb_priceoth.Text)).ToString("C2").Remove(0, 1);
                pricee = "Rp" + pricee.Remove(pricee.Length - 3, 3) + ",-";
                bool tes = false;
                for (int i = 0; i < dtstock.Rows.Count; i++)
                {
                    if (tb_nameoth.Text == dtstock.Rows[i][0].ToString() && pricee == dtstock.Rows[i][2].ToString())
                    {
                        tes = true;
                    }
                }

                if (tes == true)
                {
                    for (int i = 0; i < dtstock.Rows.Count; i++)
                    {
                        if (tb_nameoth.Text == dtstock.Rows[i][0].ToString() && pricee == dtstock.Rows[i][2].ToString())
                        {
                            int qty = (Convert.ToInt32(dtstock.Rows[i][1]) + 1);
                            string tot = (Convert.ToInt32(tb_priceoth.Text) * qty).ToString("C2").Remove(0, 1);
                            string price = (Convert.ToInt32(tb_priceoth.Text)).ToString("C2").Remove(0, 1);
                            dtstock.Rows[i][1] = qty.ToString();
                            dtstock.Rows[i][2] = "Rp" + price.Remove(price.Length - 3, 3) + ",-";
                            dtstock.Rows[i][3] = "Rp. " + tot.Remove(tot.Length - 3, 3) + ",-";
                            break;
                        }
                    }
                }
                else
                {
                    string tott = "Rp" + Convert.ToInt32(tb_priceoth.Text).ToString("C2").Remove(0, 1).Remove(tb_priceoth.Text.Length, 3) + ",-";
                    dtstock.Rows.Add(tb_nameoth.Text, '1', pricee, tott);
                    barang.Add(tb_nameoth.Text);
                }
                total = total + Convert.ToInt32(tb_priceoth.Text);
                int subtotal = total + (total * 10 / 100);
                string sub = subtotal.ToString("C2").Remove(0, 1);
                tb_subtotal.Text = "Rp. " + sub.Remove(sub.Length - 3, 3) + ",-";
                string to = total.ToString("C2").Remove(0, 1);
                tb_total.Text = "Rp. " + to.Remove(to.Length - 3, 3) + ",-";

                tb_priceoth.Text = "";
                tb_nameoth.Text = "";
            }
            tb_priceoth.Enabled = false;
            tb_nameoth.Enabled = false; ;
            pictureBox4.Image = null;
            dgv.ClearSelection();
        }

        private void tb_priceoth_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar))
            {
                if (!char.IsDigit(e.KeyChar))
                {
                    e.Handled = true;
                }
            }
        }

        private void b_up_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "PNG File (*.png)|*.png|JPEG File (*.jpeg)|*.jpeg|JPG Files (*.jpg)|*.jpg";
            ofd.InitialDirectory = "C:\\";

            ofd.ShowDialog();
            pictureBox4.Image = new Bitmap(ofd.FileName);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;

            tb_nameoth.Enabled = true;
            tb_priceoth.Enabled = true;
        }

        private void tb_nameoth_TextChanged(object sender, EventArgs e)
        {
            if (tb_nameoth.Text != "" && tb_priceoth.Text != "")
            {
                b_addoth.Enabled = true;
            }
            else
            {
                b_addoth.Enabled = false;
            }
        }

        private void tb_total_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        bool del = false;
        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            del = true;
        }

        private void b_del_Click(object sender, EventArgs e)
        {
            int tot = 0;
            if (del == true)
            {
                for (int i = 0; i < dtstock.Rows.Count; i++)
                {
                    if (dtstock.Rows[i][0].ToString() == dgv.CurrentRow.Cells[0].Value.ToString() && dtstock.Rows[i][2].ToString() == dgv.CurrentRow.Cells[2].Value.ToString())
                    {
                        dtstock.Rows.RemoveAt(i);
                        del = false;
                    }
                }
            }
            for (int i = 0; i < dtstock.Rows.Count; ++i)
            {
                string c = "";
                string[] haha = dtstock.Rows[i][3].ToString().Split('R', 'p', '.', ',', '-');
                for (int j = 0; j < haha.Length; j++)
                {
                    c = c + haha[j];
                }
                tot = tot + Convert.ToInt32(c);
            }
            total = tot;
            tb_total.Text = "Rp. " + tot.ToString("C2").Remove(0, 1).Remove(tot.ToString().Length, 3) + ",-";
            tot = tot + (tot * 10 / 100);
            tb_subtotal.Text = "Rp. " + tot.ToString("C2").Remove(0, 1).Remove(tot.ToString().Length, 3) + ",-";
            dgv.ClearSelection();
        }
    }
}
